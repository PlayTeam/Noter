#include "NoteGenerator.h"
#include <iostream>


std::vector<Note> NoteGenerator::generateNotes(Scale scale,std::vector<Note> notesWithDurations)
{
	unsigned int melodyLength=notesWithDurations.size();

	NoteName* availableNotes=scale.getAvailableNotesAsArray();

	std::vector<Note> melody;

	Note tonicNote=Note(notesWithDurations[0].getDuration(),scale.getTonicNote());

	melody.push_back(tonicNote);

	for(unsigned int i=1;i<melodyLength;i++)
	{
		int randomNoteIndex=rand()%7;
		Note newNote=Note(notesWithDurations[i].getDuration(),availableNotes[randomNoteIndex]);

		cout << "================" << endl;
		cout << "New note: " << notesWithDurations[i].getDuration() << "-" << GET_NAME(availableNotes[randomNoteIndex]) << endl;
		cout << endl;

		melody.push_back(newNote);
	}

	return melody;
}