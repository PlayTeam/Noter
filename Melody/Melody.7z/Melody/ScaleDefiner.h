#pragma once
#include <string>
#include "Scale.h"
class ScaleDefiner
{
public:
	static Scale* getScale(string text);
};

