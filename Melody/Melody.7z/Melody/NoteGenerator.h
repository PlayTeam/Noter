#pragma once
#pragma once
#include "Scale.h"
#include <vector>

class NoteGenerator
{
public:
	static std::vector<Note> generateNotes(Scale scale,std::vector<Note> notesWithDurations);
};

