#pragma once
class ScaleFactory
{
public:
	ScaleFactory(void);
	~ScaleFactory(void);



};

