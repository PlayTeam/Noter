#pragma once
#include <string>
#include "NoterContext.h"
class NotationElement
{
public:
	static enum NoteType
	{
		NOTE=1,REST
	};
	static enum NoteDuration
	{
		HALF=2,QUARTER=4,EIGHTH=8,SIXTEENTH=16
	};
	long getDurationInMillis()
	{//TODO: note duration calculation
		switch(duration)
		{
			case QUARTER:
				{
					return (long)60/NoterContext::tempo;
				}
			case EIGHTH:
				{
					return (long)60/(0.5*NoterContext::tempo);
				}
			case SIXTEENTH:
				{
					return (long)60/(0.25*NoterContext::tempo);
				}
		}
	}
	virtual std::string getName()=0;
	NoteType getNoteType()
	{
		return type;
	}
	NoteDuration getDuration()
	{
		return duration;
	}
protected:
	NoteDuration duration;
	NoteType type;
};