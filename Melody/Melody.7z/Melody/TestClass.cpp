#include "TestClass.h"

#include <vector>
#include "Generator.h"

using namespace std;

TestClass::TestClass(void)
{
}


TestClass::~TestClass(void)
{
}

int main()
{
	/*
	IMusicalInterval* mi=new MajorThird;
	std::vector<Note*> notes;

	Note* a=new Note(Note::A,Note::QUARTER);
	Note* gis=new Note(Note::Gis,Note::EIGHTH);

	notes.push_back(a);
	notes.push_back(gis);

	for(unsigned int i=0;i<notes.size();i++)
	{
		cout << notes[i]->play() << endl;
		cout << notes[i]->getNoteFrequency() << endl;
		
	}
*/
	string text;
	
	getline(cin,text);

	Gamma* scale=GammaManager::getGamma(text);
	Generator* g=new Generator();

	g->generate(scale);

	system("PAUSE");



	return 0;
}