#pragma once
#include <iostream>
class TestClass
{
public:
	TestClass(void);
	~TestClass(void);
};

